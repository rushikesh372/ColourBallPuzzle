package com.BallPuzzel.app;

import java.io.IOException;
import java.util.*;
import static com.BallPuzzel.app.MovesNode.*;
import static com.BallPuzzel.utils.IOUtils.*;
import com.BallPuzzel.custome_exception.InvalidMoveException;

public class GamePlay_user extends LoadGame{
	
	public final static Scanner IN = new Scanner(System.in);
    
	private static void undoLastMove() throws InvalidMoveException
	{
		if(Latest_Move == null)try 
		{
			System.out.println(ANSI_PURPLE+"No more moves to undo!.... Game at Initial State."+ANSI_RESET);
			throw new InvalidMoveException("No more moves to undo!.... Game at Initial State.");
			//return;
		}catch (Exception e) {	e.getStackTrace();	}
		MovesNode undo_move = Latest_Move;
		Latest_Move = Latest_Move.prev;
        ball_container[undo_move.from][undo_move.fromSection] = ball_container[undo_move.to][undo_move.toSection];
        ball_container[undo_move.to][undo_move.toSection] = null;		
		return;
	}
	
	private static void printMenu() throws InvalidMoveException, IOException, ClassNotFoundException
	{
		System.out.println("Option : \r\n"
							+ "1. Undo last move\r\n"
							+ "2. Save Game and Exit\r\n"
							+ "3. Reload last Saved Game and proceed with the same\r\n"
							+ "4. Exit\r\n"
							+ "Please Enter your Choice  : ");
		switch(IN.nextInt())
    	{
        	case 1:
	        	undoLastMove();
        		break;
        	case 2://save game state 
        		SaveGame(ball_container, filename);
        		break;
        	case 3://reload Game
        		ball_container = RestoreGame(filename);
        		break;
        	case 4:
	            System.exit(0);
	        default : 
	        	System.out.println(ANSI_PURPLE+"Invalid Choice.... Exiting from menu!... "+ANSI_RESET);
    	}
		msTimeLastUsed = System.currentTimeMillis();
	}
	
    public void readInput() throws InvalidMoveException 
    {
        System.out.println("Select bottle index \"From\" and bottle index \"To\" (OR Enter \"0\" to Show Menu option)");
        int from = IN.nextInt();
        msTimeLastUsed = System.currentTimeMillis();
        if(from <= 0) 
        {
        	if(from == 0) try 
        	{	printMenu();	} catch (Exception e) {		e.printStackTrace();	}
        	return;
        }
        
        from = from - 1;
        int to = IN.nextInt();		to = to - 1;
        msTimeLastUsed = System.currentTimeMillis();
        int fromSection = -1;
        int toSection = -1;
        if ((from >= 0) && (from < ball_container.length ) && (to >= 0) && (to < ball_container.length) && from != to ) try
        {
            for (int i = ball_container[from].length - 1; i >= 0 ; i--) 
            {
                if (ball_container[from][i] != null) 
                {
                    fromSection = i;
                    break;
                }
            }
            if (fromSection >= 0) 
            {
                for (int i = 0; i < ball_container[to].length; i++) 
                {
                    if (ball_container[to][i] == null) 
                    {
                        toSection = i;
                        break;
                    }
                }
                if (toSection >= 1) 
                {
                	if((ball_container[to][toSection-1] == ball_container[from][fromSection]))	// Valid Operation .....
                	{
                		ball_container[to][toSection] = ball_container[from][fromSection];
	                    ball_container[from][fromSection] = null;    
	                    Latest_Move = addMove(Latest_Move, to, toSection, from, fromSection);
                	}
                	else
                	{
                		System.out.println(ANSI_RED+"Invalid Operation!..."+ANSI_RESET);
                		throw new InvalidMoveException( "Inalid Move :: [to value :" + ball_container[to][toSection-1] + "\t From value :"+ ball_container[from][fromSection]+"]");
                	}
                    
                }
                else if (toSection == 0) 
                {
                    ball_container[to][toSection] = ball_container[from][fromSection];
                    ball_container[from][fromSection] = null;
                    Latest_Move = addMove(Latest_Move, to, toSection, from, fromSection);
                }
            }
    	}catch (Exception e) {	e.getStackTrace();	}
    }
}