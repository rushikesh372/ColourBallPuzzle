package com.BallPuzzel.app;

public enum Ball 
{	
	RED("\u001B[31m" + "RED" + "\u001B[0m"),
	BLUE("\u001B[34m" + "BLUE" + "\u001B[0m"),
	YELLOW("\u001B[33m" + "YELLOW" + "\u001B[0m"),
	GREEN("\u001B[32m" + "GREEN" + "\u001B[0m"),
	PURPLE("\u001B[35m" + "PURPLE" + "\u001B[0m"),
	CYAN("\u001B[36m" + "CYAN" + "\u001B[0m");
	
	@SuppressWarnings("unused")
	private String value;
	
	private Ball(String value)
	{
		this.value = value;
	}	
};
