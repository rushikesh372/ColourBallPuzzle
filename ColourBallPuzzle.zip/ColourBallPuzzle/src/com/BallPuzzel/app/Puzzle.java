package com.BallPuzzel.app;

import com.BallPuzzel.app.MovesNode;

public class Puzzle {
	
	public static MovesNode Latest_Move;
	public static long msTimeLastUsed;
	public static String filename = "./src/com/BallPuzzel/utils/SavedGameState.txt";	//"./SavedGameState.txt";
	
	public Puzzle() {
		super();
		Latest_Move  = null;
	}

	public static final String ANSI_RESET = "\u001B[0m";
	public static final String ANSI_RED = "\u001B[31m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_YELLOW = "\u001B[33m";
	public static final String ANSI_BLUE = "\u001B[34m";
	public static final String ANSI_PURPLE = "\u001B[35m";
	public static final String ANSI_CYAN = "\u001B[36m";
	public static final String ANSI_WHITE = "\u001B[37m";
	public static final String ANSI_BLACK = "\u001B[30m";

	public static String[] ballColors = {ANSI_RED+"Red"+ANSI_RESET, 
		    							ANSI_GREEN+"Green"+ANSI_RESET,  
		    							ANSI_BLUE+"Blue"+ANSI_RESET, 
		    							ANSI_YELLOW+"Yellow"+ANSI_RESET 
		    						};
    public static String[][] ball_container;

    public void printContainer() 
    {
        StringBuilder fullOutput = new StringBuilder();
        StringBuilder container;
        for (int i = 0; i < ball_container.length; i++) 
        {
            container = new StringBuilder();
            container.append(String.format("%-3s [", i+1));
            for (int j = 0; j < ball_container[i].length; j++)		//String padding right 
            {
                container.append(String.format("%-20s", ((ball_container[i][j] == null )? "<Empty>" : ball_container[i][j]+" ")));
            }

            container.append(']');
            fullOutput.append(container);
            fullOutput.append('\n');
        }
        System.out.println(fullOutput);
    }

    public boolean checkWin() 
    {
        for (int i = 0; i < ball_container.length; i++) {
            for (int j = 0; j < ball_container[i].length - 1; j++) {
                if (ball_container[i][j] != null && !ball_container[i][j].equals(ball_container[i][j + 1])) {
                    return false;
                }
            }
        }
        return true;
    }
}
