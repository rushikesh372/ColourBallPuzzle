package com.BallPuzzel.tester;

import com.BallPuzzel.custome_exception.*;
import static com.BallPuzzel.app.LoadGame.*;

import com.BallPuzzel.app.GamePlay_user;

public class GameRun {

	public static void main(String[] args) throws InvalidMoveException 
	{
		GamePlay_user newGame = new GamePlay_user();
		ball_container = new String[ballColors.length + 1][4];
        newGame.fillContainer();
        newGame.printContainer();
        System.out.println("GO!!!");
        while (!newGame.checkWin()) 
        {
        	newGame.readInput();
            newGame.printContainer();
            if (System.currentTimeMillis() - msTimeLastUsed > 1000 * 30)
        	{
        		System.out.println(ANSI_RED+"Your Time is Up!...."+ANSI_RESET);
        	    System.exit(0);
        	}
        }
        System.out.println("You win!");
    }
}
