module BallPuzzel {
	
	/*
	 * * Project Title	:	BALL SORT PUZZLE.
	 * * Authors	 	:	NEHA P. MISTRY.		(PRN: 220340120127)
	 * 					:	RUSHIKESH JAGTAP.	(PRN: 220340120161)
	 * 
	 * * Submission Date:	08-June-2022
	 * 
	 * * Description	: 	Mini-Project submitted regarding completion of the ADS module.
	 * 
	 * * Description of Game:
	 *					�	In this game there are Four Containers which are fully filled
	 *					 	with different colored balls & one Empty Container.
 	 *					�	We have to select the operation to perform on the balls, and move them according our choice, 
 	 *						so at the end all container have same colored balls & one container is in empty condition for buffering purpose.
 	 *					�	One can save intermediate game state .
 	 *					�	One can also reload the previously saved game.
 	 * 
	 * * Rules of the game : 
	 *				 	1)	Can move One ball at a time.
	 *					2)	Only the ball which is present at the top position of their respective container can only move.
	 *					3)	If You are unable to give any input in 30 seconds, then game will automatically finish.
	 *					4)	Once all balls gets sorted & grouped together perfectly w.r.t. colors then you Win and game finishes
	 *						with successful exit status.
 	 *
	 */
}